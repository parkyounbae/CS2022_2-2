package room;

public class Room {
    // 강의실 객체 정보
    private String room_id;
    private String building_id;
    private String occupancy;
}
