package hope;

public class Hope {
    // 희망 목록에 대한 정보
    private String class_id;
    private String student_id;
    private String hope_id;
}
