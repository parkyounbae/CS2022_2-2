package lecturer;

public class Lecturer {
    private String lecturer_id;
    private String name;
    private String major_id;
}
