package credit;

public class Credit {
    // 성적 정보에 대한 객체 정보 담음
    private String credits_id;
    private String student_id;
    private String course_id;
    private String credit_year;
    private String grade;
}
