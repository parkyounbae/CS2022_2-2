package major;

public class Major {
    private String major_id;
    private String name;
}
