package class_time;

public class Class_time {
    // 수업 시간 객체 정보
    private String time_id;
    private String class_id;
    private String period;
    private String begin_time;
    private String end_time;
}
