package enrollment;

public class Enrollment {
    // 수강 신청 정보 객체
    private String class_id;
    private String student_id;
    private String enrollment_id;
}
