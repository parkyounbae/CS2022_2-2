package course;

public class Course {
    private String course_id;
    private String name;
    private String credit;
}
