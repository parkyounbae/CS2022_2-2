package building;

public class Building {
    // 빌딩의 객체 정보
    private String building_id;
    private String name;
    private String department;
    private String rooms;
}
